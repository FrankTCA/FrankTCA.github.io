ColorChat | No Forge Required

For: Minecraft 1.10

This mod enables you to put colors in the chat!

WARNING: Do not use on servers. You will be immediately kicked upon formatted chat.

How to install:

Use BetterZip, WinRar, etc. to open your 1.10 version jar file in the .minecraft folder.

Put the g.class file inside of the file, and replace the old g.class.

On Mac: Delete the MOJANGC files in the META-INF folder.

On Windows: Delete the entire META-INF folder.

Save and exit.

Go into the 1.10.json file next to the jar file that you just edited.

Remove this text:

  "downloads": {
    "client": {
      "url": "https://launcher.mojang.com/mc/game/1.10/client/ba038efbc6d9e4a046927a7658413d0276895739/client.jar",
      "sha1": "ba038efbc6d9e4a046927a7658413d0276895739",
      "size": 8856992
    },
    "server": {
      "url": "https://launcher.mojang.com/mc/game/1.10/server/a96617ffdf5dabbb718ab11a9a68e50545fc5bee/server.jar",
      "sha1": "a96617ffdf5dabbb718ab11a9a68e50545fc5bee",
      "size": 9459395
    }
  },

Should be near the bottom

TIP: on Mac you can search for keyword in your file with command+f

Open up minecraft Launcher.

Deploy Minecraft 1.10

Enjoy beutiful chat!

Color Guide:

Black: §0

Dark Blue: §1

Dark Green: §2

Dark Aqua: §3

Dark Red: §4

Dark Purple: §5

Gold: §6

Light Gray: §7

Dark Gray: §8

Light Blue: §9

Light Green: §a

Light Aqua: §b

Light Red: §c

Light Purple: §d

Yellow: §e

White: §f

Format Guide:

Bold: §l

Underline: §n

Italic: §o

Obfuscated: §k

Strikethrough: §m

RESET FORMATS: §r
